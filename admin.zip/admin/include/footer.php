	<div class="footer">
		<div class="container">
			 

			<b class="copyright">&copy; IIITBH|2019 </b> All rights reserved.
		</div>
	</div>