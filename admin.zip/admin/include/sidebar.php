<div class="span3">
					<div class="sidebar">


<ul class="widget widget-menu unstyled">
							
							<li>
								<a href="manage-stud.php">
									<i class="menu-icon icon-group"></i>
									Manage Students
								</a>
							</li>
						</ul>
<ul class="widget widget-menu unstyled">
							
							<li>
								<a href="manage-facstaff.php">
									<i class="menu-icon icon-group"></i>
									Manage Faculty & Staff
								</a>
							</li>
						</ul>
<ul class="widget widget-menu unstyled">
							
							<li>
								<a href="manage-others.php">
									<i class="menu-icon icon-group"></i>
									Manage Others
								</a>
							</li>
						</ul>

<ul class="widget widget-menu unstyled">
                                <li><a href="#"><i class="menu-icon icon-tasks"></i>Student Affairs </a></li>
                                <li><a href="sa.php"><i class="menu-icon icon-tasks"></i>Add Student Affairs </a></li>
                                <li><a href="manage-sa.php"><i class="menu-icon icon-paste"></i>Manage Student Affairs</a></li>
                            </ul>
<ul class="widget widget-menu unstyled">
                                <li><a href="#"><i class="menu-icon icon-tasks"></i>Faculty Affairs </a></li>
                                <li><a href="fa.php"><i class="menu-icon icon-tasks"></i>Add Faculty Affairs </a></li>
                                <li><a href="manage-fa.php"><i class="menu-icon icon-paste"></i>Manage Faculty Affairs</a></li>
                            </ul>


						<ul class="widget widget-menu unstyled">
							<!--
							<li><a href="user-logs.php"><i class="menu-icon icon-tasks"></i>User Login Log </a></li>
							-->
							<li>
								<a href="logout.php">
									<i class="menu-icon icon-signout"></i>
									Logout
								</a>
							</li>
						</ul>

					</div><!--/.sidebar-->
				</div><!--/.span3-->
