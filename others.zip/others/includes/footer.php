 <footer class="site-footer">
          <div class="text-center">
              IIITBH|2019
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>