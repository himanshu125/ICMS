
<?php 
session_start();

 //prompt function
    function prompt($prompt_msg){
        echo("<script type='text/javascript'> var answer = prompt('".$prompt_msg."'); </script>");

        $answer = "<script type='text/javascript'> document.write(answer); </script>";
        return($answer);
    }
$x=$_SESSION['var1'];
$_SESSION['var2']=$x;
include('includes/config.php');
if(isset($_POST['submit_otp'])){ 
				$ot=$_POST['otp'];
				$result=mysqli_query($con,"select * from otp_expiry  where otp = '$ot' and email='$x'and is_expired!=1 and now()<=date_add(create_at,Interval 10 Minute)");
				$count=mysqli_num_rows($result);
				if(!empty($count)){
					$result=mysqli_query($con,"update otp_expiry set is_expired = 1 where otp='$ot'");
					header("location:registration.php");
				}
				else
				{
					 
					echo("<script type='text/javascript'> var answer = alert('Wrong Otp, Try Again'); </script>");
					
				}
			}

			?>
			<!DOCTYPE html>
<html>
<head>
<title>User Login</title>
<style>
body{
	font-family: calibri;
}
.tblLogin {
	border: #95bee6 1px solid;
    background: #d1e8ff;
    border-radius: 4px;
    max-width: 300px;
	padding:20px 30px 30px;
	text-align:center;
}
.tableheader { font-size: 20px; }
.tablerow { padding:20px; }
.error_message {
	color: #b12d2d;
    background: #ffb5b5;
    border: #c76969 1px solid;
}
.message {
	width: 100%;
    max-width: 300px;
    padding: 10px 30px;
    border-radius: 4px;
    margin-bottom: 5px;    
}
.login-input {
	border: #CCC 1px solid;
    padding: 10px 20px;
	border-radius:4px;
}
.btnSubmit {
	padding: 10px 20px;
    background: #2c7ac5;
    border: #d1e8ff 1px solid;
    color: #FFF;
	border-radius:4px;
}
</style>
</head>
<body>
		<div>
        <center>
        <img src="images/logo.png" height="100px" width="1120px">
        <hr width="1120px">
        </center>
        </div>
<br><br><br><br><br><br>
<form name="frmUser" method="post" action="otp_validate.php">
	<center>

	<div class="tblLogin">	
		<div class="tableheader">Enter OTP</div>
		<p style="color:#31ab00;">Check your email for the OTP</p>
		<p>Remember the OTP will expire in 10 Minutes.Hurry!</p>	
			
		<div class="tablerow">
			<div class="tableheader">
				<input type="email" name="useremail" required="required" value="<?php echo htmlentities($x);?>" readonly class="login-input"><br><br>
			</div>
			<input type="text" name="otp" placeholder="One Time Password" class="login-input" required>
		</div>


		<div class="tableheader"><input type="submit" name="submit_otp" value="Submit" class="btnSubmit"></div>
		
			</div>
			</center>
</form>

<?php
?>
</body></html>