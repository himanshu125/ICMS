
<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
include('includes/config.php');
date_default_timezone_set("Asia/Kolkata");

require 'PHPMailer/vendor/autoload.php';
$x=$_SESSION['var'];
$_SESSION['var1']=$x;


$var1=rand(100000,999999);
$result=mysqli_query($con," insert into otp_expiry(id,otp,create_at,is_expired,email)values('','".$var1."','".date("Y-m-d H:i:s")."',0,'".$x."') ");
$mail = new PHPMailer();
$_SESSION['var1']=$x;

$mail->isSMTP(); 
$mail->SMTPAuth = true;                                     // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com'; 
$mail->SMTPDebug = 0;                      // Specify main and backup server
$mail->Username = 'icmsiiitbh@gmail.com';                   // SMTP username
$mail->Password = 'Test@123';               // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable encryption, 'ssl' also accepted
$mail->Port = 587;                                    //Set the SMTP port number - 587 for authenticated TLS
$mail->setFrom('icmsiiitbh@gmail.com', 'ICMS IIIT Bhagalpur');     //Set who the message is to be sent from
//$mail->addReplyTo('labnol@gmail.com', 'First Last');  //Set an alternative reply-to address
//$mail->addAddress('surajfake1122@gmail.com', 'duggu');
//echo "$x hello";
$mail->addAddress($x,'duggu');  // Add a recipient
//$mail->addAddress('ellen@example.com');               // Name is optional
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');
//$mail->WordWrap = 50;                                 // Set word wrap to 50 characters
//$mail->addAttachment('/usr/labnol/file.doc');         // Add attachments
//$mail->addAttachment('/images/image.jpg', 'new.jpg'); // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'OTP for reseting password';
$mail->Body    = 'Dear Faculty/Staff, This is auto generated mail from Indian Institute of Information Technology, Bhagalpur(Internal Complaint Management System). Your one time password for recovering account is : '.$var1.'';
$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

//Read an HTML message body from an external file, convert referenced images to embedded,
//convert HTML into a basic plain-text alternative body
//$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));

if(!$mail->send()) {
   echo 'Message could not be sent.';
   //echo 'Mailer Error: ' . $mail->ErrorInfo;
   exit;
}
else{
echo 'OTP has been sent';
//header('localhost: http//localhost/cms/send_otp.php');
}
header("location:forget_otp_validate.php");	
				
		//	if($var1==$y){

		//		header('localhost: http//localhost/cms/stud/signup.php');
		//	}
		//	else {

		//		echo "Invalid OTP";
		//	}






?>
